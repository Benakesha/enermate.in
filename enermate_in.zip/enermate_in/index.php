<?php

include_once('navigation.php');

?>

<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>

<style type="text/css">
  .card .card-body>p.card-text{
    font-size: 18px;
    font-family:Georgia;
    text-align: justify;
  }
  .card .card-body>h4{
    text-align: center;
    font-weight: bold;
    color: #00BCD4;
    text-decoration: underline;
    padding-bottom: 5px;
  }
  ul>li{
    font-size: 18px;
    font-family:Georgia;
    text-align: justify;
    margin-top: 18px;
    padding-bottom: 4px;
  }

  .team-text{
    font-size: 18px;
    font-family:Georgia;
    text-align: justify;

  }
  
</style>
<br>
<div>
<h4 id="example"style="text-align: center;color: green;">Expertise in providing Services and Customised Energy Solutions</h4>
</div><br><br>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="col-md-4" style="float: left;">
          <div class="card">
          <div class="card-body">
            <h4 class="card-title"><a>ABOUT US</a></h4>
               <p class="card-text">We cater to the Energy Sector by providing Services and Customized Solutions covering both  Renewable and Non-Renewable Energy. We provide Services encompassing Marketing, Trading, and Scheduling of Power. We also provide Advisory in fields of Legal, Administrative, Project Management, Financial Management for the Energy Sector. The Services also cover Consulting and Advisory in Energy efficiency and Energy Management.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4" style="float: left;">
          <div class="card">
          <img class="card-img-top" src="images/home1.jpg" height="270" alt="Card image cap">
          <div class="card-body">
            <h4 class="card-title"><a>OUR EXPERTISE</a></h4>
            <p class="card-text">DESIGNING TAILOR-MADE ENERGY SOLUTIONS</p>
          </div>
        </div>
      </div>
      <div class="col-md-4" style="float: left;">
        <div class="card">
          <div class="card-body">
           <h4 class="card-title"><a>OUR CLIENTELE</a></h4>
              <p class="card-text">
              <ul>
                <li>Generating Companies/Merchant Power Plants</li>
                <li>Open Access consumers</li>
                <li>Group captive Generators</li>
                <li>Group Captive Consumers</li>
                <li>Renewable Energy Generators</li>
                <li>State Distribution Companies</li>
              </ul>
          </p>
        </div>
        </div>
      </div>
    </div>
  </div>  
  <br><br>
  <div class="row">
    <div class="col-md-12">
      <h4 style="text-align: center;font-weight: bold;text-decoration: underline;color: #00BCD4;">OUR TEAM</h4>
      <div class="col-md-1" style="float: left;"></div>
      <div class="col-md-4" style="float: left;">
        <img src="images/team.jpg">
      </div>
      <div class="col-md-6" style="float: left;padding-top: 20px;margin-top: 50px;">
        <p class="team-text">A well diversified team of professionals and associates with decades of experience in power sector, catering to all segments of power industry right from Project Conception, Consulting, Project Implementation, Daily Operations, O&M, Power Trading, Power Marketing, Compliance to Regulatory framework and Litigation in Energy Sector.</p>
      </div>
    </div>
  </div>  
<div class="container" style="margin-top: 40px;margin-bottom: 20px;">
  <div class="row">
  <div class="col-md-12">
    <h4 style="text-align: center;font-weight: bold;text-decoration: underline;color: #00BCD4;padding-bottom: 40px;">OUR CLIENTS</h4>
    <div class="owl-carousel owl-theme">
    <div><img src="images/clientlogo/microsoft.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/qualcomm-logo.png" width="30" height="100"></div>
    <div><img src="images/clientlogo/slr-metaliks-logo.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/recipharma.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/cargill.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/badve.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/bosch.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/cavendish.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/kemwell.webp" width="30" height="100"></div>
    <div><img src="images/clientlogo/kernlibers.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/druvadesh.png" width="30" height="100"></div>
    <div><img src="images/clientlogo/sipani.png" width="30" height="100"></div>
    <div><img src="images/clientlogo/southern.jpg" width="30" height="100"></div>
    <div><img src="images/clientlogo/spicer.gif" width="30" height="100"></div>
    </div>
  </div>
  </div>
</div>

<footer style="margin-left: -30px;margin-right: -30px;padding-left: 0px;padding-right: 0px;" class="page-footer font-small unique-color-dark">

        <div style="background-color: #00BCD4">
          <div class="container">
           <div class="row py-4 d-flex align-items-center">
              <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
                <h6 class="mb-0">Get connected with us on social networks!</h6>
              </div>
        
              <div class="col-md-6 col-lg-7 text-center text-md-right">
                <a class="fb-ic" href="http://www.facebook.com">
                  <i class="fa fa-facebook white-text mr-4"> </i>
                </a>
                <a class="tw-ic" href="http://www.twitter.com">
                  <i class="fa fa-twitter white-text mr-4"> </i>
                </a>
              
                <a class="gplus-ic" href="http://www.googleplus.com">
                  <i class="fa fa-google-plus white-text mr-4"> </i>
                </a>
             
                <a class="li-ic" href="http://www.linedin.com">
                  <i class="fa fa-linkedin white-text mr-4"> </i>
                </a>
              
                <a class="ins-ic" href="http://www.instagram.com">
                  <i class="fa fa-instagram white-text"> </i>
                </a>

              </div>
          
            </div>
          
          </div>
        </div>

        <div class="container text-center text-md-left mt-5">

          <div class="row mt-3">
  
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

              <h6 class="text-uppercase font-weight-bold">Enermate</h6>
              <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p><img src="images/logo.jpg" width="200" height="150"></p>

            </div>
           
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

              <h6 class="text-uppercase font-weight-bold">Services</h6>
              <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                ENERGY MANAGEMENT
              </p>
              <p>
               ENERGY TRADING
              </p>
              <p>
                ENERGY SCHEDULING 
              </p>
              <p>
                 ENERGY ANALYSIS 
              </p>
              <p>
                LEGAL AND ADMINISTRATIVE
              </p>
            
            </div>
            
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

              <h6 class="text-uppercase font-weight-bold">Contact</h6>
              <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                <i class="fa fa-home mr-3"></i>EnerMate Energy Service Pvt. Ltd.</p>  
              <p>
                <i class="fa fa-map-marker mr-3"></i> Bangalore, India</p>
              <p>
                <i class="fa fa-envelope mr-3"></i> enermatenergy@gmail.com</p>
              <p>
                <i class="fa fa-phone mr-3"></i> + 91 94495 53545</p>
             
            </div>
         
          </div>
        
        </div>
        
        <div class="footer-copyright text-center py-3">© 2015 Copyright:
          <a href="https://mdbootstrap.com/bootstrap-tutorial/"> EnerMate Energy Service Pvt. Ltd.</a>
        </div>
      
      </footer>
  
  
<script type="text/javascript">
  
      $('.owl-carousel').owlCarousel({
        items:3,
        loop:true,
        margin:10,
        autoplay:true,
        autoplayTimeout:1500,
        autoplayHoverPause:true
    });

</script> 
