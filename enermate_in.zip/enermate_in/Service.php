<?php
	
	include_once('navigation.php');

?>

<style type="text/css">
	.card .card-body .card-title>a{
		text-align: center;
		font-weight: bold;
		color: #00BCD4;
		text-decoration: underline;
		padding-bottom: 5px;
		font-size: 18px;
	}
	ul>li{
		font-size: 16px;
		font-family:Georgia;
		text-align: justify;
		margin-top: 16px;
	
	}
	.card{
		margin-left: -10px;

	}
</style>
<div class="container-fluid" style="margin-bottom: 10%;margin-top: 7%;">
	<div class="row">
		<div class="col-md-12" style="margin-top: 4%;">
			<div class="col-md-4" style="float: left;">
				<!-- Card -->
				<div class="card">
					<div class="card-body">
				    <!-- Title -->
				    <h6 class="card-title"><a>ENERGY MANAGEMENT AND PROJECTS</a></h6>
				    <!-- Text -->
				    <p class="card-text">
					<ul>
				    	<li>Energy Portfolio Management</li>
				    	<li>Energy Management Services</li>
				    	<li>Project Advisory Services</li>
				    	<li>Feasibility Report Studies</li>
				    	<li>Techno Commercial Advisory Services</li>
				    	<li>Regulatory and Policy Advisory Services</li>
				    	<li>Financial Advisory Services</li>
				    </ul>
					</p>
				 	</div>
				</div>
				<!-- Card -->
			</div>
			<div class="col-md-4" style="float: left;">
				<!-- Card -->
				<div class="card">
					<div class="card-body">
				    <!-- Title -->
				    <h6 class="card-title"><a>ENERGY TRADING, SCHEDULING  & ANALYSIS</a></h6>
				    <!-- Text -->
				    <p class="card-text">
				    	<ul>
				    		<li>Short and Medium Term Bilateral Contracts</li>
				    		<li>Energy Transactions(Buying/Selling) through Power Exchanges</li>
				    		<li>Open Access Tie up for Sale/Purchase</li>
				    		<li>Group Captive Tie up for Sale/Purchase</li>
				    		<li>Power Trading Analysis</li>
				    		<li>Forecasting of Price Rates</li>
				    		<li>Preparing Power Bidding Documents (Pre-Sale) and Invoices(Post-Sale)</li>
				    		<li>Due-Diligence of buyers/sellers</li>

				    	</ul>

					</p>
				 	</div>
				</div>
				<!-- Card -->
			</div>
			<div class="col-md-4" style="float: left;">
				<!-- Card -->
				<div class="card">
					<div class="card-body">
				    <!-- Title -->
				    <h6 class="card-title"><a>LEGAL AND ADMINISTRATIVE </a></h6>
				    <!-- Text -->
				    <p class="card-text">
				    	<ul>
				    		<li>Legal Consultancy and advisory</li>
				    		<li>Approvals from Nodal agencies</li>
				    		<li>Follow up with CTU/STU</li>
				    		<li>Timely execution of contracts</li>
				    		<li>Negotiating better terms</li>
				    		<li>Resolving Issues and queries</li>
				    	</ul>

					</p>
				 	</div>
				</div>
				<!-- Card -->
			</div>

		</div>
	</div>
</div>
<footer style="margin-left: -30px;margin-right: -30px;padding-left: 0px;padding-right: 0px;" class="page-footer font-small unique-color-dark">

		    <div style="background-color: #00BCD4">
		      <div class="container">

		        <!-- Grid row-->
		        <div class="row py-4 d-flex align-items-center">

		          <!-- Grid column -->
		          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
		            <h6 class="mb-0">Get connected with us on social networks!</h6>
		          </div>
		          <!-- Grid column -->

		          <!-- Grid column -->
		          <div class="col-md-6 col-lg-7 text-center text-md-right">

		            <!-- Facebook -->
		            <a class="fb-ic" href="http://www.facebook.com">
		              <i class="fa fa-facebook white-text mr-4"> </i>
		            </a>
		            <!-- Twitter -->
		            <a class="tw-ic" href="http://www.twitter.com">
		              <i class="fa fa-twitter white-text mr-4"> </i>
		            </a>
		            <!-- Google +-->
		            <a class="gplus-ic" href="http://www.googleplus.com">
		              <i class="fa fa-google-plus white-text mr-4"> </i>
		            </a>
		            <!--Linkedin -->
		            <a class="li-ic" href="http://www.linedin.com">
		              <i class="fa fa-linkedin white-text mr-4"> </i>
		            </a>
		            <!--Instagram-->
		            <a class="ins-ic" href="http://www.instagram.com">
		              <i class="fa fa-instagram white-text"> </i>
		            </a>

		          </div>
		          <!-- Grid column -->

		        </div>
		        <!-- Grid row-->

		      </div>
		    </div>

		    <!-- Footer Links -->
		    <div class="container text-center text-md-left mt-5">

		      <!-- Grid row -->
		      <div class="row mt-3">

		        <!-- Grid column -->
		        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

		          <!-- Content -->
		          <h6 class="text-uppercase font-weight-bold">Enermate</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p><img src="images/logo.jpg" width="200" height="150"></p>

		        </div>
		        <!-- Grid column -->

		        <!-- Grid column -->
		        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

		          <!-- Links -->
		          <h6 class="text-uppercase font-weight-bold">Services</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p>
		            ENERGY MANAGEMENT
		          </p>
		          <p>
		           ENERGY TRADING
		          </p>
		          <p>
		            ENERGY SCHEDULING 
		          </p>
		          <p>
		             ENERGY ANALYSIS 
		          </p>
		          <p>
		            LEGAL AND ADMINISTRATIVE
		          </p>
		        
		        </div>
		        <!-- Grid column -->

		        <!-- Grid column -->
		      <!--  <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

		        
		          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p>
		            <a href="#!">Your Account</a>
		          </p>
		          <p>
		            <a href="#!">Become an Affiliate</a>
		          </p>
		          <p>
		            <a href="#!">Shipping Rates</a>
		          </p>
		          <p>
		            <a href="#!">Help</a>
		          </p> 

		        </div>-->
		        <!-- Grid column -->

		        <!-- Grid column -->
		        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

		          <!-- Links -->
		          <h6 class="text-uppercase font-weight-bold">Contact</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p>
		          	<i class="fa fa-home mr-3"></i>EnerMate Energy Service Pvt. Ltd.</p>  
		          <p>
		            <i class="fa fa-map-marker mr-3"></i> Bangalore, India</p>
		          <p>
		            <i class="fa fa-envelope mr-3"></i> enermatenergy@gmail.com</p>
		          <p>
		            <i class="fa fa-phone mr-3"></i> + 91 94495 53545</p>
		         
		        </div>
		        <!-- Grid column -->

		      </div>
		      <!-- Grid row -->

		    </div>
		    <!-- Footer Links -->

		    <!-- Copyright -->
		    <div class="footer-copyright text-center py-3">© 2015 Copyright:
		      <a href="https://mdbootstrap.com/bootstrap-tutorial/"> EnerMate Energy Service Pvt. Ltd.</a>
		    </div>
		    <!-- Copyright -->

		  </footer>
		  <!-- Footer -->
