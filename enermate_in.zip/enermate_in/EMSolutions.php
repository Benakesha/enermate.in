<?php
	
	include_once('navigation.php');

?>
<style type="text/css">
	b{
		color: green;
		font-weight: bold;
	}
	.container{
		font-family: Georgia;
	}
	h4{
		text-decoration: underline;
	}
</style>

<div class="container" style="margin-top: 10%;margin-bottom: 10%;">
	<div class="row">
		<div class="col-md-12">
			<h5>We offer customized Energy Marketing Services suiting to individual business requirements</h5><br>
			<h4 style="color: orange;font-weight: bold;">ENERGY MARKETING SERVICES</h4>
			<p style="text-align: justify;">In India, power Trading is carried out under "non discriminatory open access" regulations of CERC/SERCs and open access procedures of CTU/STUs. We facilitate trading of power from State Utilities, Captive Power Plants, Independent Power Producers, Merchant Power Plants as well as renewable energy sources to industrial consumers, open access consumers, private utilities</p>   
			<h4 style="color: #00BCD4;margin-bottom: 15px;font-weight: bold;">Bilateral Trading Contracts</h4>
			<p><b>Short Term Contracts :</b>Due to uncertainty linked with power generation and non bankability of power, the short term trading of power is growing at a very fast pace. We match the availability of power from the suppliers and the customers requirement, scheduling of power flow on a day-ahead basis and also on term-ahead basis taking into account and balancing requirements of both the parties. We facilitate the power trading transactions by securing the necessary Concurrences for open access from Nodal Regional Load Despatch Centre (RLDC) and ensure Operational efficiency through continuous and close co-ordination with various intervening agencies e.g. CTU, STUs, RLDCs, SLDCs along with Buyers/Sellers.</p>
			<p><b>Medium Term and Long Term Contracts :</b> We offer to sell power on medium / long term basis through bidding route with state utilities or bilateral/negotiated route to various Distribution Companies/ other customers. Under bidding route, we offer services of Bid Development, Competitive scenario analysis and Bidding strategies. We also offer to sell power to Industrial and Commercial category customers on a mid-term/ long term basis, providing a reliable and economical supply </p>
			<p><b>Trading through Power Exchange :</b> We facilitate trading of power through power exchanges. Indian Energy Exchange (IEX) and Power Exchange of India Limited (PXIL) are the two exchanges which are in operation in India to facilitate an automated on-line platform for physical day-ahead contracts.  </p>
			<p><b>Power tie-up through Open Access Consumers :</b>Open Access allows large users of power, typically having connected load of 1 MW and above, to buy cheaper power from the open market. Open Access also helps consumers to procure power during load restriction period. We offer various options to industrial and commercial consumers for purchase of power on both bilateral basis and through power exchange based on the power requirement and market conditions from both conventional and renewable sources.</p>
			<p><b>Power tie up to Group Captive Consumers :</b> We also have tie up with Generators who are on other side on Group Captive Consumers. Generator to consumer utility is cost effective, reliable and committed power is available to consumer. This is available for both renewable and non renewable sources </p>
			<p><b>Tailor made Solutions :</b> We design and execute tailor made solutions for different generators depending on their generating pattern, internal consumption and market demand</p>
			
			<h4 style="color: orange;font-weight: bold;">OUR STRENGTHS</h4>
			<p>
				<ul>
					<li>Domain Expertise in All segments of Energy Trading</li>
					<li>We believe in developing and nurturing long term relationship with our clients by understanding their requirement and provide customised solutions</li>
					<li>Liasoning with generators, distributors, Regional Load Despatch Centres, CTU/STU ie transmission agencies for timely execution of contracts and receipt of payment</li>
					<li>Leveraging our expertise in power operations, legal, marketing, finance, administration to provide comprehensive result oriented and economic solutions</li>
					<li>Tying up for short term as well as long term power agreements ensuring viability and business success.</li>
					<ul>
				</p>
					</div>
				</div>
</div>

<footer style="margin-left: -30px;margin-right: -30px;padding-left: 0px;padding-right: 0px;" class="page-footer font-small unique-color-dark">

		    <div style="background-color: #00BCD4">
		      <div class="container">

		        <!-- Grid row-->
		        <div class="row py-4 d-flex align-items-center">

		          <!-- Grid column -->
		          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
		            <h6 class="mb-0">Get connected with us on social networks!</h6>
		          </div>
		          <!-- Grid column -->

		          <!-- Grid column -->
		          <div class="col-md-6 col-lg-7 text-center text-md-right">

		            <!-- Facebook -->
		            <a class="fb-ic" href="http://www.facebook.com">
		              <i class="fa fa-facebook white-text mr-4"> </i>
		            </a>
		            <!-- Twitter -->
		            <a class="tw-ic" href="http://www.twitter.com">
		              <i class="fa fa-twitter white-text mr-4"> </i>
		            </a>
		            <!-- Google +-->
		            <a class="gplus-ic" href="http://www.googleplus.com">
		              <i class="fa fa-google-plus white-text mr-4"> </i>
		            </a>
		            <!--Linkedin -->
		            <a class="li-ic" href="http://www.linedin.com">
		              <i class="fa fa-linkedin white-text mr-4"> </i>
		            </a>
		            <!--Instagram-->
		            <a class="ins-ic" href="http://www.instagram.com">
		              <i class="fa fa-instagram white-text"> </i>
		            </a>

		          </div>
		          <!-- Grid column -->

		        </div>
		        <!-- Grid row-->

		      </div>
		    </div>

		    <!-- Footer Links -->
		    <div class="container text-center text-md-left mt-5">

		      <!-- Grid row -->
		      <div class="row mt-3">

		        <!-- Grid column -->
		        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

		          <!-- Content -->
		          <h6 class="text-uppercase font-weight-bold">Enermate</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p><img src="images/logo.jpg" width="200" height="150"></p>

		        </div>
		        <!-- Grid column -->

		        <!-- Grid column -->
		        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

		          <!-- Links -->
		          <h6 class="text-uppercase font-weight-bold">Services</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p>
		            ENERGY MANAGEMENT
		          </p>
		          <p>
		           ENERGY TRADING
		          </p>
		          <p>
		            ENERGY SCHEDULING 
		          </p>
		          <p>
		             ENERGY ANALYSIS 
		          </p>
		          <p>
		            LEGAL AND ADMINISTRATIVE
		          </p>
		        
		        </div>
		        <!-- Grid column -->

		        <!-- Grid column -->
		      <!--  <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

		        
		          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p>
		            <a href="#!">Your Account</a>
		          </p>
		          <p>
		            <a href="#!">Become an Affiliate</a>
		          </p>
		          <p>
		            <a href="#!">Shipping Rates</a>
		          </p>
		          <p>
		            <a href="#!">Help</a>
		          </p> 

		        </div>-->
		        <!-- Grid column -->

		        <!-- Grid column -->
		        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

		          <!-- Links -->
		          <h6 class="text-uppercase font-weight-bold">Contact</h6>
		          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
		          <p>
		          	<i class="fa fa-home mr-3"></i>EnerMate Energy Service Pvt. Ltd.</p>  
		          <p>
		            <i class="fa fa-map-marker mr-3"></i> Bangalore, India</p>
		          <p>
		            <i class="fa fa-envelope mr-3"></i> enermatenergy@gmail.com</p>
		          <p>
		            <i class="fa fa-phone mr-3"></i> + 91 94495 53545</p>
		         
		        </div>
		        <!-- Grid column -->

		      </div>
		      <!-- Grid row -->

		    </div>
		    <!-- Footer Links -->

		    <!-- Copyright -->
		    <div class="footer-copyright text-center py-3">© 2015 Copyright:
		      <a href="https://mdbootstrap.com/bootstrap-tutorial/"> EnerMate Energy Service Pvt. Ltd.</a>
		    </div>
		    <!-- Copyright -->

		  </footer>
		  <!-- Footer -->
