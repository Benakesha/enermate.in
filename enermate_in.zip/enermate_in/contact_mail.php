<?php
if(isset( $_POST['username']))
  $username = $_POST['username'];
if(isset( $_POST['email']))
  $email = $_POST['email'];
if(isset( $_POST['message']))
  $message = $_POST['message'];
if(isset( $_POST['subject']))
  $subject = $_POST['subject'];

?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">

    let username = '<?php echo $username;?>',
        email= '<?php echo $email;?>',
        subject= '<?php echo $subject;?>',
        message= '<?php echo $message;?>';

     $.ajax({
            type : 'POST', 
            url  : ,//'./EmailService/contact_us_mail.php', 
            data : { name:username, emails:email, sub:subject, msg:message}, 
            success: function(response){
            <?php 
            header("location:/enermate_in/Contact.php?msg=hai");
            ?>
            } 
      });

</script>