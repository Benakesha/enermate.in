<!DOCTYPE html>
<html>
<head>
  <title></title>
    <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.14/css/mdb.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/navigation.css">
  
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark cyan fixed-top">

    <!-- Navbar brand -->
    <a class="navbar-brand" href="index.php" style="margin-top: -10px;padding-top: -5px;margin-bottom: -5px;"><img src="images/logo.jpg" width="150" height="80" style="margin-bottom: -5px;"></a>

    <!-- Collapse button -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
      aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Collapsible content -->
    <div class="collapse navbar-collapse" id="basicExampleNav">

      <!-- Links --> 
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home &nbsp;&nbsp;
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Service.php" style="margin-left: 10px;">Services&nbsp;&nbsp;&nbsp;</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="EMSolutions.php">Energy Marketing Solutions&nbsp;&nbsp;&nbsp;</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Contact.php">Contact Us&nbsp;&nbsp;</a>
        </li>
                
      </ul>
      <!-- Links -->

    </div>
    <!-- Collapsible content -->

  </nav>
  <!--/.Navbar-->




<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.14/js/mdb.min.js"></script>
</body>
</html>

